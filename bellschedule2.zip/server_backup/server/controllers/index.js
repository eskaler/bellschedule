const profileController = require('./profileController');
// const bell = require('./bellController');
// const profile = require('./bellController');
// const user = require('./user');

module.exports = {
    profileController,
    // bellController
}