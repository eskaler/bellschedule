// const profileController = require('./profileController');
// const dayController = require('./dayController');
// const userController = require('./userController');


// module.exports = {
//     profileController,
//     dayController,
//     userController
// }