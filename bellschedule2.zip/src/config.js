module.exports = {
  HOST: 'http://localhost',
  PORT: '3456',
  POSTFIX: 'api',
  ESPIP: 'http://192.168.100.10/'
}